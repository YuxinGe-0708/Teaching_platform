pm.test("Status Test", function () {
    pm.response.to.have.status(200);
});

pm.test("Body Test", function () {
    const responseJson = pm.response.json();
    pm.expect(responseJson.code).to.eql(0);
});